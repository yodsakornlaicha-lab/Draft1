@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js not found. Install Node.js 18 or newer from https://nodejs.org/
 pause
 exit /b 1
)
start "" "http://localhost:4173"
echo StockScope TH is running. Keep this window open.
node server.js
pause
