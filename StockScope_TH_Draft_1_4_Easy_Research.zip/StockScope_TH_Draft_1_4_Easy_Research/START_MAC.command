#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js 18+ is required. Install from https://nodejs.org/'
  read -r _
  exit 1
fi
(sleep 2; open http://localhost:4173) &
echo 'StockScope TH is running. Keep this Terminal open.'
node server.js
