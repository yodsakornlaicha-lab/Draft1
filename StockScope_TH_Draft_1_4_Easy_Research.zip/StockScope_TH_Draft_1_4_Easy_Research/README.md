# StockScope TH — Draft 1.3 / Unified Relationship & ML Insights

## What changed
- Removed the separate **ML Methods Demo** top-level Stock Research tab.
- Combined all its unique mock features into **Stock Relationship & ML Insights**.
- Three subtabs: **Relationship** (Similarity, Peer Discovery, Relationship Network, Correlation Matrix, financial/business relationships), **Clustering Models** (K-Means, Hierarchical, PCA, adjustable K, mock dendrogram), and **Classification** (Risk, Growth, Financial Health, Earnings Surprise, Market Regime, Random Forest / XGBoost conceptual outputs and all-stock classification table).
- Avoids duplicated clustering charts in Relationship; clustering is centralized in Clustering Models.
- Kept Stock Analysis, Stock Comparison, Market Intelligence with 8 demo news stories, Portfolio, Discovery and the original price-chart backend.

## Important
All financial fundamentals, clustering plots, scores, classifications, correlations and news headlines are **MOCK / DEMO**. No ML model is trained, no live news feed or OpenAI API is used. Price chart still uses the prior remote price feed when available.

## Run
Run `npm start` in the project folder and browse `http://localhost:4173` (or the port displayed). The HTML can also be viewed standalone, but price data needs the backend.


## Draft 1.4 — Plain Thai Research Labels
Stock Research tab names and core explanations now use easy Thai investor-oriented questions. All interactions, mock calculations and other pages are preserved. Financial/ML outputs are demo-only, not investment advice.
