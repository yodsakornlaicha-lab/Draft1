'use strict';
/** StockScope TH V13: small local web + market data relay.
 * Requires Node >= 18, no npm packages. Do not deploy publicly without authentication,
 * caching, rate limits, exchange redistribution permission and approved data source.
 * Yahoo chart endpoint is unofficial, best-effort and NOT guaranteed real-time.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || '0.0.0.0';
const SOURCE = (process.env.MARKET_PROVIDER || 'yahoo').toLowerCase();
const TTL = 55000;
const cache = new Map();
function reply(res,status,data,type='application/json; charset=utf-8'){
  res.writeHead(status,{'Content-Type':type,'Cache-Control': 'no-store','X-Content-Type-Options':'nosniff'});
  res.end(typeof data==='string'?data:JSON.stringify(data));
}
function normalizeSymbol(raw){
  const s=String(raw||'').toUpperCase().trim();
  if(!/^[A-Z0-9]{1,12}$/.test(s))throw new Error('Invalid Thai stock ticker');
  return s;
}
function dateStr(unix){return new Date(unix*1000).toISOString().slice(0,10)}
function dateLocal(v){return String(v).slice(0,10)}
function normalizeRows(rows){
  const dates=new Set();
  return rows.filter(x=>x&&Number.isFinite(x.open)&&Number.isFinite(x.high)&&Number.isFinite(x.low)&&Number.isFinite(x.close)&&x.high>=Math.max(x.open,x.close)&&x.low<=Math.min(x.open,x.close)&&x.close>0)
   .filter(x=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(x.time)||dates.has(x.time))return false;dates.add(x.time);return true})
   .sort((a,b)=>a.time.localeCompare(b.time));
}
async function timedJson(url,opts={}){
 const ac=new AbortController();const timer=setTimeout(()=>ac.abort(),10000);
 try {const r=await fetch(url,{...opts,signal:ac.signal,headers:{'User-Agent':'StockScope-TH-ProofOfConcept/0.1','Accept':'application/json',...(opts.headers||{})}});
 if(!r.ok)throw new Error('Upstream data provider error (HTTP '+r.status+')');return await r.json();}
 finally {clearTimeout(timer)}
}
async function yahooData(ticker){
 const bases = process.env.YAHOO_CHART_BASE_URL
   ? [process.env.YAHOO_CHART_BASE_URL]
   : ['https://query2.finance.yahoo.com/v8/finance/chart/','https://query1.finance.yahoo.com/v8/finance/chart/'];
 let j, lastError;
 for(const base of bases){
   try {j=await timedJson(base+encodeURIComponent(ticker)+'.BK?interval=1d&range=1y');break}
   catch(e){lastError=e;console.warn('[yahoo fallback]',base,e.message)}
 }
 if(!j)throw new Error('Yahoo Finance unreachable: '+(lastError?.message||'Provider unavailable'));
 const result=j?.chart?.result?.[0];if(!result)throw new Error(j?.chart?.error?.description || 'Symbol is not available from chart provider');
 const q=result.indicators?.quote?.[0];if(!q)throw new Error('Provider returned no OHLC candles');
 const bars=(result.timestamp||[]).map((ts,i)=>({time:dateStr(ts),open:Number(q.open?.[i]),high:Number(q.high?.[i]),low:Number(q.low?.[i]),close:Number(q.close?.[i]),volume:Number(q.volume?.[i]||0)}));
 const candles=normalizeRows(bars);
 if(candles.length<25)throw new Error('Insufficient price history for technical indicators');
 const meta=result.meta||{};
 return {symbol:ticker,source:'Yahoo Finance (unofficial chart feed)',mode:'LATEST AVAILABLE · NOT VERIFIED LIVE',delayNote:'Exchange delay/entitlement not verified',latestBarTime:meta.regularMarketTime?new Date(meta.regularMarketTime*1000).toISOString():candles.at(-1).time+'T00:00:00Z',cadence:'daily',dataMarket:meta.exchangeName||'SET',disclosure:'Unofficial endpoint; availability can change. Not licensed for production redistribution. Market data may be delayed and is not a real-time stream.',candles};
}
async function twelveData(ticker){
 const key=process.env.TWELVE_DATA_API_KEY;
 if(!key)throw new Error('TWELVE_DATA_API_KEY is not configured');
 // Exchange coverage, entitlements and interval access depend on provider contract.
 const url='https://api.twelvedata.com/time_series?symbol='+encodeURIComponent(ticker)+'&exchange=SET&interval=1day&outputsize=260&apikey='+encodeURIComponent(key);
 const j=await timedJson(url);
 if(j.status==='error'||!Array.isArray(j.values))throw new Error(j.message||'This ticker/exchange is not supported by current provider plan');
 const candles=normalizeRows(j.values.map(d=>({time:dateLocal(d.datetime),open:Number(d.open),high:Number(d.high),low:Number(d.low),close:Number(d.close),volume:Number(d.volume)||0})));
 if(candles.length<25)throw new Error('Insufficient price history');
 return {symbol:ticker,source:'Twelve Data',mode:'LATEST AVAILABLE · CHECK SUBSCRIPTION',delayNote:'Data cadence and exchange delay depend on Twelve Data subscription',latestBarTime:candles.at(-1).time+'T00:00:00Z',cadence:'daily',dataMarket:'SET',disclosure:'Daily OHLCV data retrieved with a user-supplied data key. Check SET coverage, redistribution, real-time entitlements and timestamps before publishing.',candles};
}
async function getCandles(ticker){
 const k=SOURCE+':'+ticker;const entry=cache.get(k);if(entry&&Date.now()-entry.when<TTL)return entry.value;
 const value=await (SOURCE==='twelve'?twelveData(ticker):SOURCE==='yahoo'?yahooData(ticker):Promise.reject(new Error('Unsupported MARKET_PROVIDER')));
 cache.set(k,{value,when:Date.now()});return value;
}
const srv=http.createServer(async(req,res)=>{
 let u;try{u=new URL(req.url,'http://localhost')}catch{return reply(res,400,{error:'Bad URL'})}
 if(req.method!=='GET')return reply(res,405,{error:'GET only'});
 if(u.pathname==='/api/health')return reply(res,200,{ok:true,provider:SOURCE,mode:'Latest available market OHLCV, not certified real-time',serverTime:new Date().toISOString()});
 if(u.pathname==='/api/candles'){
  try{const symbol=normalizeSymbol(u.searchParams.get('symbol'));return reply(res,200,await getCandles(symbol))}
  catch(e){console.error('[market feed]',String(e.message));return reply(res,502,{error:String(e.message).slice(0,190)})}
 }
 if(u.pathname==='/robots.txt')return reply(res,200,'User-agent: *\nDisallow: /','text/plain; charset=utf-8');
 if(u.pathname==='/'||u.pathname==='/index.html')return reply(res,200,fs.readFileSync(path.join(root,'index.html'),'utf8'),'text/html; charset=utf-8');
 return reply(res,404,{error:'Not found'});
});
if(require.main===module)srv.listen(PORT,HOST,()=>console.log('StockScope TH V13 at http://localhost:'+PORT+' · provider='+SOURCE));
module.exports={srv,normalizeRows,normalizeSymbol,getCandles};
